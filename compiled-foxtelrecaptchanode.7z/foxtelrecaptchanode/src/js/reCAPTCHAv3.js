const ReCAPTCHAv3Node = function (document, siteKeyIn) {

    const siteKey = siteKeyIn;
    let reCaptchaRdy = false;
    let reCapSubmitting = false;
    let frComponents = {
        panel: null,
        loginBtn: null,
        inputs: null,
        reCapCode: null
    }

    //console.log('ReCAPTCHAv3Node loaded started with siteKey ' + siteKey);

    this.init = function () {
        //console.log('Init recaptcha');
        frComponents.panel = document.getElementById('frLoginContainer'); // Grab the panel (this is a custom id)
        //console.log(frComponents);
        frComponents.panel.style.display = 'none'; // hide the entire panel while loading
        //dummyHidden(); // Use this if debugging in chrome console
        injetReCAPTCHA();
    }

    /*const dummyHidden = function () {
        let hidden = document.createElement('input');
        hidden.id = 'reCAPTCHAv3Code';
        hidden.type = 'text';
        hidden.value = 'reCAPTCHAv3Code';
        document.forms[0].prepend(hidden);
    }*/

    // Injects the reCAPTCHA script into the html DOM.
    const injetReCAPTCHA = function () {
        if (typeof grecaptcha === 'undefined') {
            //console.log('Injecting the reCAPTCHA');
            let recaptchaScript = document.createElement('script');
            recaptchaScript.type = 'text/javascript';
            recaptchaScript.setAttribute('async', '');
            recaptchaScript.setAttribute('defer', '');
            let greCaptcha = 'https://www.google.com/recaptcha/api.js';
            let onloadQry = 'onload=reCaptchaOnLoad';
            let renderQry = 'render=' + siteKey;
            let reCAPTCHAurl = greCaptcha + '?' + onloadQry + '&' + renderQry;
            //console.log('reCAPTCHA URL: ' + reCAPTCHAurl);
            recaptchaScript.src = reCAPTCHAurl;
            document.body.appendChild(recaptchaScript);
        } else {
            //console.log('reCAPTCHA already running');
            reCaptchaOnLoad();
        }
    }

    // reCAPTCHA calls this once it finishes loading which will bootstrap everything else.
    this.reCaptchaOnLoad = function () {
        if (!reCaptchaRdy) {
            //console.log('reCAPTCHA has finished loading.');
            grecaptcha.ready(function () {
                reCaptchaRdy = true;
                waitForDOM();
            });
        } else {
            waitForDOM();
        }
    }

    // Try and find the login button which will be the last thing to render, if not keep trying every 10ms.
    const waitForDOM = function () {
        frComponents.loginBtn = document.querySelector('input[type=submit]'); 
        if (frComponents.loginBtn === null) {
            setTimeout(function () {
                //console.log('Wait for login button');
                waitForDOM();
            }, 10);
        } else {
            //console.log('Found login button');
            // if the button has been rendeded all inputs should be present.
            frComponents.inputs = document.getElementsByClassName("input-lg");
            // And the hidden field for the recaptcha code to go in to get POSTd back to AM.
            frComponents.reCapCode = document.getElementById('reCAPTCHAv3Code');
            registerEvents();
        }
    }

    // Registers all the event listeners
    const registerEvents = function () {
        frComponents.loginBtn.type = "button"; // Set the button type from submit to button so we can run code first without it submitting
        frComponents.loginBtn.addEventListener('click', clickSubmit); // Run the submit function on click.

        // If enter is pressed it will simulate clicking the submit button rather then directly submitting the form.
        for (var i = 0; i < frComponents.inputs.length; i++) {
            frComponents.inputs[i].addEventListener("keyup", hitEnter);
        }
        
        frComponents.panel.style.display = 'block'; // Everything is set up so we can show the login page.
    }

    // Traps the enter key and hits the submit button
    const hitEnter = function (e) {
        if (e.keyCode === 13) {
            e.preventDefault();
            frComponents.loginBtn.click();
        }
    }

    // This itercepts the standard submit, excutes the recaptcha and gets the code,
    // then does the standard click submit the second time which is processed by ForgeRock AM.
    const clickSubmit = function (e) {
        //console.log('login button clicked - submitting: ' + (reCapSubmitting ? 'form' : 'reCAPTCHA'));
        //console.log('login button type:' + frComponents.loginBtn.getAttribute('type'));
        if (reCapSubmitting === false) {
            //e.preventDefault();
            reCapSubmitting = true;
            frComponents.loginBtn.setAttribute('disabled', true); // Disable the login button while processing
            // Get the reCAPTCHA code from Google
            grecaptcha.execute(siteKey, { action: 'OAuthExtLogin' })
                .then(function (token) {
                    //console.log('reCAPTCHA: ' + token);
                    frComponents.reCapCode.value = token; // We got the code so add it to the hidden callback.
                    // Make the submit button active and able to submit the form.
                    frComponents.loginBtn.type = "submit";
                    frComponents.loginBtn.removeAttribute('disabled');
                    // Now click this button again, but it will submit this time with the reCAPTCHA code.
                    frComponents.loginBtn.click();
                });
        } else {
            //console.log('Submitting with code: ' + frComponents.reCapCode.value);
            reCapSubmitting = false;
        }
    }

}

const reCAPTCHAv3Node = new ReCAPTCHAv3Node(
    document,
    '6LcNfPcUAAAAAHZpVNHL1i_aCwskz7l5ybE0a6L9'
);

// reCAPTCHA will call this on load. Has to be in the global scope for it to have access it.
function reCaptchaOnLoad() {
    reCAPTCHAv3Node.reCaptchaOnLoad();
}

reCAPTCHAv3Node.init();