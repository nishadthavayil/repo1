/*
 * The contents of this file are subject to the terms of the Common Development and
 * Distribution License (the License). You may not use this file except in compliance with the
 * License.
 *
 * You can obtain a copy of the License at legal/CDDLv1.0.txt. See the License for the
 * specific language governing permission and limitations under the License.
 *
 * When distributing Covered Software, include this CDDL Header Notice in each file and include
 * the License file at legal/CDDLv1.0.txt. If applicable, add the following below the CDDL
 * Header, with the fields enclosed by brackets [] replaced by your own identifying
 * information: "Portions copyright [year] [name of copyright owner]".
 *
 * Copyright 2018 ForgeRock AS.
 */
package au.com.foxtel.reCAPTCHANode;

import com.google.common.collect.ImmutableList;
import com.google.inject.assistedinject.Assisted;
import com.sun.identity.authentication.callbacks.HiddenValueCallback;
import com.sun.identity.authentication.callbacks.ScriptTextOutputCallback;
import com.sun.identity.shared.debug.Debug;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.forgerock.openam.annotations.sm.Attribute;
import org.forgerock.openam.auth.node.api.*;
import org.forgerock.openam.core.CoreWrapper;

import org.forgerock.guava.common.base.Strings;

import javax.inject.Inject;
import javax.security.auth.callback.Callback;
import org.forgerock.openam.plugins.PluginException;
import org.forgerock.openam.plugins.PluginTools;

/**
 * Stuff
 */
@Node.Metadata(outcomeProvider = SingleOutcomeNode.OutcomeProvider.class,
        configClass = FoxtelLoginFailMsg.Config.class)
public class FoxtelLoginFailMsg extends SingleOutcomeNode {

    private final Config config;
    private final CoreWrapper coreWrapper;
    private final static String DEBUG_FILE = "FoxtelReCAPTCHA";
    protected Debug debug = Debug.getInstance(DEBUG_FILE);
    private boolean render = true;

    /**
     * Configuration for the node.
     */
    public interface Config {

    }

    /**
     * Create the node.
     *
     * @param config The service config.
     * @throws NodeProcessException If the configuration was not valid.
     */
    @Inject
    public FoxtelLoginFailMsg(@Assisted Config config, CoreWrapper coreWrapper) throws NodeProcessException {
        this.config = config;
        this.coreWrapper = coreWrapper;
    }

    @Override
    public Action process(TreeContext context) throws NodeProcessException {

        //String failMsg = config.failMessage().toString();
        //debug.error("failMsg: " + failMsg);

        /*
            The JavaScript code below has been obfuscated.
            It was done @ https://obfuscator.io/ with additonal settings:
                "Disable console output"
            The raw .js code is under \src\js\FoxtelLoginFailMsg.js
         */
        String javascript = "const _0x4264=['add','div','#f2410a','custom-alert','innerHTML','https://www.foxtel.com.au/login/forgot/forgot-password-email-check.html','append','login-error-msg','classList','underline','style','href','textDecoration','span','reset\\x20your\\x20password','\\x20\\x20\\x20The\\x20username\\x20and\\x20password\\x20you\\x20entered\\x20did\\x20not\\x20match\\x20our\\x20records.\\x20Try\\x20again,\\x20','\\x20or\\x20','login-error-text','getElementById','color','prepend','createElement','alert-message-icon','login-error-icon','remove'];(function(_0x3804d1,_0x42649d){const _0x30a9e4=function(_0x1c26b8){while(--_0x1c26b8){_0x3804d1['push'](_0x3804d1['shift']());}};_0x30a9e4(++_0x42649d);}(_0x4264,0x14f));const _0x30a9=function(_0x3804d1,_0x42649d){_0x3804d1=_0x3804d1-0x0;let _0x30a9e4=_0x4264[_0x3804d1];return _0x30a9e4;};(function(){let _0x46774c=document[_0x30a9('0x8')](_0x30a9('0x16'));if(typeof _0x46774c!=='undefined'&&_0x46774c!==null){_0x46774c[_0x30a9('0xe')]();}let _0x129dcd=document[_0x30a9('0xb')](_0x30a9('0x10'));_0x129dcd[_0x30a9('0x17')][_0x30a9('0xf')](_0x30a9('0x12'));_0x129dcd[_0x30a9('0x17')]['add'](_0x30a9('0xc'));_0x129dcd['id']='login-error-msg';_0x129dcd[_0x30a9('0x0')][_0x30a9('0x9')]='#f2410a';let _0x140688=document['createElement']('i');_0x140688['id']=_0x30a9('0xd');_0x140688[_0x30a9('0x17')][_0x30a9('0xf')]('fa');_0x140688[_0x30a9('0x17')][_0x30a9('0xf')](_0x30a9('0xc'));let _0x39da39=document[_0x30a9('0xb')](_0x30a9('0x3'));_0x39da39['id']=_0x30a9('0x7');let _0x4b0938=[];_0x4b0938[0x0]=_0x30a9('0x5');_0x4b0938[0x1]=document[_0x30a9('0xb')]('a');_0x4b0938[0x1][_0x30a9('0x0')]['color']=_0x30a9('0x11');_0x4b0938[0x1][_0x30a9('0x0')][_0x30a9('0x2')]='underline';_0x4b0938[0x1]['innerHTML']=_0x30a9('0x4');_0x4b0938[0x1][_0x30a9('0x1')]=_0x30a9('0x14');_0x4b0938[0x2]=_0x30a9('0x6');_0x4b0938[0x3]=document['createElement']('a');_0x4b0938[0x3]['style'][_0x30a9('0x9')]=_0x30a9('0x11');_0x4b0938[0x3][_0x30a9('0x0')][_0x30a9('0x2')]=_0x30a9('0x18');_0x4b0938[0x3][_0x30a9('0x13')]='retrieve\\x20your\\x20username';_0x4b0938[0x3][_0x30a9('0x1')]='https://www.foxtel.com.au/login/forgot/forgot-username.html';_0x4b0938[0x4]='.';_0x39da39[_0x30a9('0x15')](_0x4b0938[0x0]);_0x39da39['append'](_0x4b0938[0x1]);_0x39da39['append'](_0x4b0938[0x2]);_0x39da39[_0x30a9('0x15')](_0x4b0938[0x3]);_0x39da39[_0x30a9('0x15')](_0x4b0938[0x4]);_0x129dcd[_0x30a9('0x15')](_0x140688);_0x129dcd[_0x30a9('0x15')](_0x39da39);let _0x13edcb=document['getElementsByTagName']('fieldset');_0x13edcb[0x0][_0x30a9('0xa')](_0x129dcd);}());";

        ScriptTextOutputCallback failureScript = new ScriptTextOutputCallback(javascript);
        HiddenValueCallback errorCallback = new HiddenValueCallback("errorCallback");

        ImmutableList<Callback> callbacks = ImmutableList.of(failureScript, errorCallback);

        Optional<String> result = context.getCallback(HiddenValueCallback.class)
                .map(HiddenValueCallback::getValue);
        
        if (result.isPresent()) {
            return goToNext().build();
        }

        return Action.send(callbacks).build();

    }
}
