/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.com.foxtel.reCAPTCHANode;

/**
 *
 * @author redfernm
 */
public enum FoxtelreCAPTCHATypes {
    V3("v3"),
    V2("v2");
    
    private String reCapVer;
 
    FoxtelreCAPTCHATypes(String reCapVer) {
        this.reCapVer = reCapVer;
    }
 
    public String toString() {
        return reCapVer;
    }
}
