/*
 * The contents of this file are subject to the terms of the Common Development and
 * Distribution License (the License). You may not use this file except in compliance with the
 * License.
 *
 * You can obtain a copy of the License at legal/CDDLv1.0.txt. See the License for the
 * specific language governing permission and limitations under the License.
 *
 * When distributing Covered Software, include this CDDL Header Notice in each file and include
 * the License file at legal/CDDLv1.0.txt. If applicable, add the following below the CDDL
 * Header, with the fields enclosed by brackets [] replaced by your own identifying
 * information: "Portions copyright [year] [name of copyright owner]".
 *
 * Copyright 2018 ForgeRock AS.
 */
package au.com.foxtel.reCAPTCHANode;

import com.google.common.collect.ImmutableList;
import com.google.inject.assistedinject.Assisted;
import com.sun.identity.authentication.callbacks.HiddenValueCallback;
import com.sun.identity.authentication.callbacks.ScriptTextOutputCallback;
import com.sun.identity.shared.debug.Debug;
import java.util.Optional;
import org.forgerock.openam.annotations.sm.Attribute;
import org.forgerock.openam.auth.node.api.*;
import org.forgerock.openam.core.CoreWrapper;

import org.forgerock.guava.common.base.Strings;

import javax.inject.Inject;
import javax.security.auth.callback.Callback;

/**
 * Stuff
 */
@Node.Metadata(outcomeProvider = SingleOutcomeNode.OutcomeProvider.class,
        configClass = FoxtelReCAPTCHANode.Config.class)
public class FoxtelReCAPTCHANode extends SingleOutcomeNode {

    private final Config config;
    private final CoreWrapper coreWrapper;
    private final static String DEBUG_FILE = "FoxtelReCAPTCHA";
    protected Debug debug = Debug.getInstance(DEBUG_FILE);

    /**
     * Configuration for the node.
     */
    public interface Config {

        @Attribute(order = 10)
        default String reCAPTCHAKey() {
            return "Enter your reCAPTCHA client key";
        }

        @Attribute(order = 20)
        default FoxtelreCAPTCHATypes reCAPTCHAType() {
            return FoxtelreCAPTCHATypes.V3;
        }

    }

    /**
     * Create the node.
     *
     * @param config The service config.
     * @throws NodeProcessException If the configuration was not valid.
     */
    @Inject
    public FoxtelReCAPTCHANode(@Assisted Config config, CoreWrapper coreWrapper) throws NodeProcessException {
        this.config = config;
        this.coreWrapper = coreWrapper;        
    }
    
    @Override
    public Action process(TreeContext context) throws NodeProcessException {

        String siteKey = config.reCAPTCHAKey().toString();
        debug.message("siteKey: " + siteKey);
        FoxtelreCAPTCHATypes recaptchaVersion = config.reCAPTCHAType();
        debug.message("recaptchaVersion: " + recaptchaVersion);
        String callbackId = null;
        String javascript = null;

        /* 
            The JavaScript code below has been obfuscated.
            It was done @ https://obfuscator.io/.
            The raw .js code is under \src\js
        */
        if (recaptchaVersion == FoxtelreCAPTCHATypes.V3) {
            // \src\js\reCAPTCHAv3.js
        	debug.message("FoxtelreCAPTCHATypes.V3: " + recaptchaVersion);
            javascript = "const _0x1ea5=['src','keyup','body','render=','display','getElementById','frLoginContainer','none','block','inputs','setAttribute','type','https://www.google.com/recaptcha/api.js','keyCode','text/javascript','button','reCaptchaOnLoad','defer','OAuthExtLogin','reCapCode','async','querySelector','init','appendChild','length','then','createElement','reCAPTCHAv3Code','click','loginBtn','onload=reCaptchaOnLoad','preventDefault','execute','disabled','input-lg','style','undefined','value','addEventListener','panel'];(function(_0x219b76,_0x1ea526){const _0x1570fa=function(_0x5bc6bd){while(--_0x5bc6bd){_0x219b76['push'](_0x219b76['shift']());}};_0x1570fa(++_0x1ea526);}(_0x1ea5,0xf1));const _0x1570=function(_0x219b76,_0x1ea526){_0x219b76=_0x219b76-0x0;let _0x1570fa=_0x1ea5[_0x219b76];return _0x1570fa;};const ReCAPTCHAv3Node=function(_0x1da20a,_0x4e3443){const _0x1cc1f8=_0x4e3443;let _0x445e12=![];let _0x14cc4d=![];let _0x25be47={'panel':null,'loginBtn':null,'inputs':null,'reCapCode':null};this['init']=function(){_0x25be47[_0x1570('0x26')]=_0x1da20a['getElementById'](_0x1570('0x5'));_0x25be47[_0x1570('0x26')][_0x1570('0x22')][_0x1570('0x3')]=_0x1570('0x6');_0x439c4c();};const _0x439c4c=function(){if(typeof grecaptcha===_0x1570('0x23')){let _0x257dc6=_0x1da20a[_0x1570('0x19')]('script');_0x257dc6[_0x1570('0xa')]=_0x1570('0xd');_0x257dc6[_0x1570('0x9')](_0x1570('0x13'),'');_0x257dc6['setAttribute'](_0x1570('0x10'),'');let _0x42ded4=_0x1570('0xb');let _0xb64cd5=_0x1570('0x1d');let _0x2b1535=_0x1570('0x2')+_0x1cc1f8;let _0x911c85=_0x42ded4+'?'+_0xb64cd5+'&'+_0x2b1535;_0x257dc6[_0x1570('0x27')]=_0x911c85;_0x1da20a[_0x1570('0x1')][_0x1570('0x16')](_0x257dc6);}else{reCaptchaOnLoad();}};this[_0x1570('0xf')]=function(){if(!_0x445e12){grecaptcha['ready'](function(){_0x445e12=!![];_0x1ff305();});}else{_0x1ff305();}};const _0x1ff305=function(){_0x25be47[_0x1570('0x1c')]=_0x1da20a[_0x1570('0x14')]('input[type=submit]');if(_0x25be47[_0x1570('0x1c')]===null){setTimeout(function(){_0x1ff305();},0xa);}else{_0x25be47[_0x1570('0x8')]=_0x1da20a['getElementsByClassName'](_0x1570('0x21'));_0x25be47[_0x1570('0x12')]=_0x1da20a[_0x1570('0x4')](_0x1570('0x1a'));_0x56158e();}};const _0x56158e=function(){_0x25be47['loginBtn'][_0x1570('0xa')]=_0x1570('0xe');_0x25be47[_0x1570('0x1c')][_0x1570('0x25')](_0x1570('0x1b'),_0x5fe742);for(var _0x2e093d=0x0;_0x2e093d<_0x25be47[_0x1570('0x8')][_0x1570('0x17')];_0x2e093d++){_0x25be47[_0x1570('0x8')][_0x2e093d][_0x1570('0x25')](_0x1570('0x0'),_0x35b55b);}_0x25be47['panel'][_0x1570('0x22')][_0x1570('0x3')]=_0x1570('0x7');};const _0x35b55b=function(_0x7b8e79){if(_0x7b8e79[_0x1570('0xc')]===0xd){_0x7b8e79[_0x1570('0x1e')]();_0x25be47[_0x1570('0x1c')][_0x1570('0x1b')]();}};const _0x5fe742=function(_0x69a4e0){if(_0x14cc4d===![]){_0x14cc4d=!![];_0x25be47[_0x1570('0x1c')][_0x1570('0x9')]('disabled',!![]);grecaptcha[_0x1570('0x1f')](_0x1cc1f8,{'action':_0x1570('0x11')})[_0x1570('0x18')](function(_0x2bcca3){_0x25be47[_0x1570('0x12')][_0x1570('0x24')]=_0x2bcca3;_0x25be47[_0x1570('0x1c')][_0x1570('0xa')]='submit';_0x25be47[_0x1570('0x1c')]['removeAttribute'](_0x1570('0x20'));_0x25be47[_0x1570('0x1c')][_0x1570('0x1b')]();});}else{_0x14cc4d=![];}};};const reCAPTCHAv3Node=new ReCAPTCHAv3Node(document,'" + siteKey + "');function reCaptchaOnLoad(){reCAPTCHAv3Node[_0x1570('0xf')]();}reCAPTCHAv3Node[_0x1570('0x15')]();";
            callbackId = "reCAPTCHAv3Code";
        } else if (recaptchaVersion == FoxtelreCAPTCHATypes.V2) {
            // \src\js\reCAPTCHAv2.js
        	debug.message("FoxtelreCAPTCHATypes.V2: " + recaptchaVersion);
            javascript = "const _0x1895=['appendChild','undefined','loginBtn','display','init','reCAPTCHAv2Div','align','append','render=explicit','panel','body','getResponse','inputs','input-lg','parentNode','getElementById','remember-forgot\\x20clearfix','script','setAttribute','text/javascript','type','reCaptchaOnLoad','center','onload=reCaptchaOnLoad','reCapCode','render','style','src','value','g-recaptcha','none','defer','block','https://www.google.com/recaptcha/api.js','querySelector','async','input[type=submit]','reCAPTCHAv2Code','getElementsByClassName'];(function(_0x3b089e,_0x1895f0){const _0x32cd3f=function(_0x7c8198){while(--_0x7c8198){_0x3b089e['push'](_0x3b089e['shift']());}};_0x32cd3f(++_0x1895f0);}(_0x1895,0x15c));const _0x32cd=function(_0x3b089e,_0x1895f0){_0x3b089e=_0x3b089e-0x0;let _0x32cd3f=_0x1895[_0x3b089e];return _0x32cd3f;};const ReCAPTCHAv2Node=function(_0x1d1e0a,_0x212fe5){const _0x37ee92=_0x212fe5;let _0x961052=![];let _0x100697={'panel':null,'loginBtn':null,'inputs':null,'reCapCode':null};let _0x1b0b98=null;this[_0x32cd('0x7')]=function(){_0x100697[_0x32cd('0xc')]=_0x1d1e0a[_0x32cd('0x12')]('frLoginContainer');_0x100697[_0x32cd('0xc')][_0x32cd('0x1d')][_0x32cd('0x6')]=_0x32cd('0x21');let _0x518ecc=_0x1d1e0a[_0x32cd('0x2')](_0x32cd('0x13'));_0x518ecc[0x0]['remove']();_0x2cb3e2();};const _0x2cb3e2=function(){if(typeof grecaptcha===_0x32cd('0x4')){let _0x5f4814=_0x1d1e0a['createElement'](_0x32cd('0x14'));_0x5f4814[_0x32cd('0x17')]=_0x32cd('0x16');_0x5f4814[_0x32cd('0x15')](_0x32cd('0x26'),'');_0x5f4814[_0x32cd('0x15')](_0x32cd('0x22'),'');let _0x4bca52=_0x32cd('0x24');let _0x2ff475=_0x32cd('0x1a');let _0x2ae34f=_0x32cd('0xb');let _0x4cfe99=_0x4bca52+'?'+_0x2ff475+'&'+_0x2ae34f;_0x5f4814[_0x32cd('0x1e')]=_0x4cfe99;_0x1d1e0a[_0x32cd('0xd')][_0x32cd('0x3')](_0x5f4814);}else{reCaptchaOnLoad();}};this[_0x32cd('0x18')]=function(){if(!_0x961052){_0x961052=!![];_0x954aa5();}else{_0x954aa5();}};const _0x954aa5=function(){_0x100697['loginBtn']=_0x1d1e0a[_0x32cd('0x25')](_0x32cd('0x0'));if(_0x100697[_0x32cd('0x5')]===null){setTimeout(function(){_0x954aa5();},0xa);}else{_0x100697[_0x32cd('0xf')]=_0x1d1e0a['getElementsByClassName'](_0x32cd('0x10'));_0x100697[_0x32cd('0x1b')]=_0x1d1e0a[_0x32cd('0x12')](_0x32cd('0x1'));_0x100697[_0x32cd('0x5')][_0x32cd('0x1d')][_0x32cd('0x6')]=_0x32cd('0x21');_0x527c6a();}};const _0x527c6a=function(){let _0x487030=_0x1d1e0a['createElement']('div');_0x487030['id']=_0x32cd('0x8');_0x487030['class']=_0x32cd('0x20');_0x487030[_0x32cd('0x9')]=_0x32cd('0x19');_0x100697[_0x32cd('0x1b')][_0x32cd('0x11')][_0x32cd('0xa')](_0x487030);_0x1b0b98=grecaptcha[_0x32cd('0x1c')](_0x32cd('0x8'),{'sitekey':_0x37ee92,'callback':_0x49c647});_0x100697[_0x32cd('0xc')]['style'][_0x32cd('0x6')]=_0x32cd('0x23');};const _0x49c647=function(){let _0x28134f=grecaptcha[_0x32cd('0xe')](_0x1b0b98);_0x100697[_0x32cd('0x1b')][_0x32cd('0x1f')]=_0x28134f;_0x100697[_0x32cd('0x5')]['click']();};};const reCAPTCHAv2Node=new ReCAPTCHAv2Node(document,'" + siteKey + "');function reCaptchaOnLoad(){reCAPTCHAv2Node[_0x32cd('0x18')]();}reCAPTCHAv2Node[_0x32cd('0x7')]();";
            callbackId = "reCAPTCHAv2Code";
        } else {
        	debug.message("Exception: " + "reCAPTCHA type must be v3 or v2 but you have " + recaptchaVersion.toString());
            throw new NodeProcessException("reCAPTCHA type must be v3 or v2 but you have " + recaptchaVersion.toString());
        }

        ScriptTextOutputCallback recaptchaScript = new ScriptTextOutputCallback(javascript);
        HiddenValueCallback recaptchaCallback = new HiddenValueCallback(callbackId);

        ImmutableList<Callback> callbacks = ImmutableList.of(recaptchaScript, recaptchaCallback);

        Optional<String> result = context.getCallback(HiddenValueCallback.class)
                .map(HiddenValueCallback::getValue)
                .filter(scriptOutput -> !Strings.isNullOrEmpty(scriptOutput));

        if (result.isPresent()) {
            String reCAPTCHAcode = result.get();
            debug.message("Foxtel reCAPTCHA " + recaptchaVersion.toString() + " code: " + reCAPTCHAcode);
            debug.message("before goto: " + callbackId +":"+ reCAPTCHAcode);
            return goToNext()
                    .replaceSharedState(context.sharedState.copy().put(callbackId, reCAPTCHAcode))
                    .build();
        }

        return Action.send(callbacks).build();
    }
}

