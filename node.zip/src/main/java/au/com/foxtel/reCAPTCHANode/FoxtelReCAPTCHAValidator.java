/*
 * The contents of this file are subject to the terms of the Common Development and
 * Distribution License (the License). You may not use this file except in compliance with the
 * License.
 *
 * You can obtain a copy of the License at legal/CDDLv1.0.txt. See the License for the
 * specific language governing permission and limitations under the License.
 *
 * When distributing Covered Software, include this CDDL Header Notice in each file and include
 * the License file at legal/CDDLv1.0.txt. If applicable, add the following below the CDDL
 * Header, with the fields enclosed by brackets [] replaced by your own identifying
 * information: "Portions copyright [year] [name of copyright owner]".
 *
 * Copyright 2017 ForgeRock AS.
 */

 /*
  This node calls the Google reCAPTCHA API to validate the code.
  It takes the following properties:
    reCAPTCHAType = v3 or v2
    reCAPTCHASecret = xxxxxxxxxxxxxxxxxxxx
    reCAPTCHAv3Threshold = 0.7
  If the type is v3 and the result is less than reCAPTCHAv3Threshold then then the result will be "Suspect".
  A suspect result should then have a 2FA or reCAPTCHA v2 challange.
  This node has the following outcomes:
    OK (good score)
    Suspect (bad score)
    Fail (validation problem)
    Error (Could not get result)
 */
package au.com.foxtel.reCAPTCHANode;

import com.google.inject.assistedinject.Assisted;
import com.sun.identity.shared.debug.Debug;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.forgerock.openam.annotations.sm.Attribute;
import org.forgerock.openam.auth.node.api.*;
import org.forgerock.openam.core.CoreWrapper;
import org.forgerock.json.JsonValue;
import org.forgerock.util.i18n.PreferredLocales;
import static org.forgerock.openam.auth.node.api.Action.goTo;
import static org.forgerock.openam.auth.node.api.SharedStateConstants.USERNAME;
import javax.inject.Inject;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static org.forgerock.json.JsonValue.field;
import static org.forgerock.json.JsonValue.json;
import static org.forgerock.json.JsonValue.object;
import org.forgerock.json.JsonValueException;
import org.forgerock.openam.utils.JsonValueBuilder;

/**
 * Stuff
 */
@Node.Metadata(outcomeProvider = FoxtelReCAPTCHAValidator.OutcomeProvider.class,
        configClass = FoxtelReCAPTCHAValidator.Config.class)
public class FoxtelReCAPTCHAValidator implements Node {

    private static final String OK = "OK";
    private static final String SUSPECT = "Suspect";
    private static final String FAILED = "Failed";
    private static final String ERROR = "Error";

    private final Config config;
    private final CoreWrapper coreWrapper;
    private final static String DEBUG_FILE = "FoxtelReCAPTCHA";
    protected Debug debug = Debug.getInstance(DEBUG_FILE);
    private FoxtelLogger logger = new FoxtelLogger(debug);

    /**
     * Configuration for the node.
     */
    public interface Config {

        @Attribute(order = 10)
        default FoxtelreCAPTCHATypes reCAPTCHAType() {
            return FoxtelreCAPTCHATypes.V3;
        }

        @Attribute(order = 20)
        default String reCAPTCHASecret() {
            return "Enter your reCAPTCHA secret key";
        }

        @Attribute(order = 30)
        default String reCAPTCHAv3Threshold() {
            return "0.7";
        }

    }

    /* v3 example result (v2 is missing score and action)
        {
            "success": true,
            "challenge_ts": "2020-05-27T03:01:06Z",
            "hostname": "www.foxtel.com.au",
            "score": 0.9,
            "action": "OAuthExtLogin"
        }*/
    private class ReCaptchaResult {

        FoxtelreCAPTCHATypes recaptchaVersion;
        boolean success = false;
        String challenge_ts = "n/a";
        String hostname = "n/a";
        double score = -99.0;
        String action = "n/a";
        List<Object> errorcodes;
    }
    ReCaptchaResult reCaptchaResult = new ReCaptchaResult();

    /**
     * Create the node.
     *
     * @param config The service config.
     * @throws NodeProcessException If the configuration was not valid.
     */
    @Inject
    public FoxtelReCAPTCHAValidator(@Assisted Config config, CoreWrapper coreWrapper) throws NodeProcessException {
        this.config = config;
        this.coreWrapper = coreWrapper;
    }

    // Add to the ForgeRock audit logging event ("nodeExtraLogging")
    @Override
    public JsonValue getAuditEntryDetail() {
        JsonValue logValue = json(object());
        if (reCaptchaResult.success) {
            if (reCaptchaResult.recaptchaVersion == FoxtelreCAPTCHATypes.V2) {
                logValue = json(
                        object(
                                field("recaptchaVersion", reCaptchaResult.recaptchaVersion.toString()),
                                field("success", reCaptchaResult.success),
                                field("challenge_ts", reCaptchaResult.challenge_ts),
                                field("hostname", reCaptchaResult.hostname)
                        )
                );
            } else if (reCaptchaResult.recaptchaVersion == FoxtelreCAPTCHATypes.V3) {
                logValue = json(
                        object(
                                field("recaptchaVersion", reCaptchaResult.recaptchaVersion.toString()),
                                field("success", reCaptchaResult.success),
                                field("challenge_ts", reCaptchaResult.challenge_ts),
                                field("hostname", reCaptchaResult.hostname),
                                field("score", reCaptchaResult.score),
                                field("action", reCaptchaResult.action)
                        )
                );
            }
        } else {
            logValue = json(
                    object(
                            field("recaptchaVersion", reCaptchaResult.recaptchaVersion.toString()),
                            field("success", reCaptchaResult.success),
                            field("error-codes", reCaptchaResult.errorcodes)
                    )
            );
        }
        return logValue;
    }

    @Override
    public Action process(TreeContext context) throws NodeProcessException {

        // Get the reCAPTCHA type from the config
        FoxtelreCAPTCHATypes recaptchaVersion = config.reCAPTCHAType();
        reCaptchaResult.recaptchaVersion = recaptchaVersion;
        logger.setReCAPTCHAType(recaptchaVersion.toString());

        // Grab the session username
        String username = context.sharedState.get(USERNAME).asString();
        logger.setUsername(username);

        // Grab the IP of the user
        String clientIP = getClientIP(context);
        logger.setClientIP(clientIP);

        // Get the reCAPTCHA secret key from the config.
        String reCAPTCHASecret = config.reCAPTCHASecret();

        logger.message("secretKey = " + reCAPTCHASecret);

        // Set the name of the callback hiddeninput field
        String callbackId = null;
        if (recaptchaVersion == FoxtelreCAPTCHATypes.V3) {
            callbackId = "reCAPTCHAv3Code";
        } else if (recaptchaVersion == FoxtelreCAPTCHATypes.V2) {
            callbackId = "reCAPTCHAv2Code";
        }

        // Get the reCAPTCHA response from the login callback
        String reCAPTCHAResponse = context.sharedState.get(callbackId).asString();
        // Remove the reCAPTCHA response from the shared state
        // (did not use transient state as there could be imput between the node and validation)
        JsonValue newSharedState = context.sharedState.copy();
        newSharedState.remove(callbackId);
        logger.message("reCAPTCHAResponse = " + reCAPTCHAResponse);

        // If the reCAPTCHA is v3 grab the trigger threshold
        double reCAPTCHAv3Threshold = 0.0;
        if (recaptchaVersion == FoxtelreCAPTCHATypes.V3) {
            try {
                reCAPTCHAv3Threshold = Double.parseDouble(config.reCAPTCHAv3Threshold());
            } catch (NumberFormatException e) {
                logger.error("Can't convert " + config.reCAPTCHAv3Threshold() + " to a double - " + e.getMessage());
                return goTo(ERROR).replaceSharedState(newSharedState).build();
            }
        }

        // Perform input sanitisation
        if (clientIP == null) {
            logger.error("Unable to extract the clientIP.");
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }
        if (reCAPTCHAResponse == null || reCAPTCHAResponse.trim().isEmpty()) {
            logger.error("Response code is not supplied by the client.");
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }
        if (recaptchaVersion == FoxtelreCAPTCHATypes.V3 && (reCAPTCHAv3Threshold < 0.0 || reCAPTCHAv3Threshold > 1.0)) {
            logger.error("reCAPTCHAv3Threshold is out of bounds (must be between 0.0 and 1.0)");
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }
        if (reCAPTCHASecret == null || reCAPTCHASecret.trim().isEmpty()) {
            logger.error("reCAPTCHASecret has not been set!");
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }

        // Call Google to validate the reCAPTCHA response
        String output = "";
        try {
            output = callReCaptchaSiteVerify(clientIP, reCAPTCHAResponse, reCAPTCHASecret);
        } catch (Exception e) {
            logger.error(e.getMessage());
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }

        // Now parse the returned JSON into the main reCAPTCHAResult class
        try {
            parseReCaptcha(output, recaptchaVersion);
        } catch (Exception e) {
            logger.error(e.getMessage());
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        }

        // Finally validate that the results are OK
        String validated = validateReCaptcha(recaptchaVersion, reCAPTCHAv3Threshold);
        if (null == validated) {
            logger.error("Unknown error");
            return goTo(ERROR).replaceSharedState(newSharedState).build();
        } else {
            switch (validated) {
                case OK:
                    return goTo(OK).replaceSharedState(newSharedState).build();
                case SUSPECT:
                    return goTo(SUSPECT).replaceSharedState(newSharedState).build();
                case FAILED:
                    return goTo(FAILED).replaceSharedState(newSharedState).build();
                default:
                    logger.error("Unknown error");
                    return goTo(ERROR).replaceSharedState(newSharedState).build();
            }
        }

    }

    // This grabs the IP address of the client logging in
    // Either from the headers inserted by Akamai or the F5, or the request if not found.
    private String getClientIP(TreeContext context) {
        String theClientIP = null;
        List<String> trueClientIP = context.request.headers.get("true-client-ip");
        logger.message("trueClientIP " + trueClientIP.toString());
        List<String> xForwardFor = context.request.headers.get("X-Forwarded-For");
        logger.message("xForwardFor " + xForwardFor.toString());
        String clientIP = context.request.clientIp;
        logger.message("context.request.clientIp " + clientIP);

        if (!trueClientIP.isEmpty()) {
            theClientIP = trueClientIP.get(0);
            logger.message("Using trueClientIP");
        } else if (!xForwardFor.isEmpty()) {
            String[] xForwardForSplit = xForwardFor.get(0).split(",", 0);
            theClientIP = xForwardForSplit[0];
            logger.message("Using xForwardFor");
        } else if (clientIP != null) {
            logger.message("Using clientIP");
            theClientIP = clientIP;
        }

        // Make sure its a valid IPv4 or IPv6 address
        // Regex from https://stackoverflow.com/questions/23483855/javascript-regex-to-validate-ipv4-and-ipv6-address-no-hostnames
        if (theClientIP != null) {
            final String regex = "((^\\s*((([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))\\s*$)|(^\\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?\\s*$))";
            final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
            final Matcher matcher = pattern.matcher(theClientIP);
            if (!matcher.matches()) {
                logger.error("IP regex fails on " + theClientIP);
                theClientIP = null;
            };
        }

        // Override internal Foxtel IP to external IP for testing
        if (theClientIP != null && !theClientIP.isEmpty() && (theClientIP.contains("10.8.") || theClientIP.contains("10.5."))) {
            theClientIP = "203.18.236.135";
        }

        return theClientIP;
    }

    // Call Googles siteverify API to get a result
    private String callReCaptchaSiteVerify(String clientIP, String reCAPTCHAResponse, String reCAPTCHASecret)
            throws MalformedURLException, UnsupportedEncodingException, IOException, Exception {

        String output = "";

        String payload = "secret=" + URLEncoder.encode(reCAPTCHASecret, "UTF-8")
                + "&response=" + URLEncoder.encode(reCAPTCHAResponse, "UTF-8")
                + "&remoteip=" + URLEncoder.encode(clientIP, "UTF-8");

        logger.message("POST payload = " + payload);

        URL url = new URL("https://www.google.com/recaptcha/api/siteverify");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "ForgeRock AM 6.0");
        byte[] postData = payload.getBytes(StandardCharsets.UTF_8);
        conn.setRequestProperty("Content-Length", Integer.toString(postData.length));

        try (DataOutputStream wr = new DataOutputStream(conn.getOutputStream())) {
            wr.write(postData);
        }

        logger.message("conn.getResponseCode() " + conn.getResponseCode());

        if (conn.getResponseCode() != 200) {
            throw new Exception("HTTP error code : " + conn.getResponseCode());
        }

        BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
        String outputBuffer;
        while ((outputBuffer = br.readLine()) != null) {
            output = output + outputBuffer;
        }

        logger.message("output = " + output);

        conn.disconnect();

        return output;
    }

    // Now we parse the JSON data model and make sure all required data is there
    private void parseReCaptcha(String output, FoxtelreCAPTCHATypes reCAPTCHAType)
            throws Exception {

        try {
            JsonValue outputJSON = JsonValueBuilder.toJsonValue(output);

            JsonValue success = outputJSON.get("success");
            logger.message("JSON success = " + success);
            reCaptchaResult.success = success.asBoolean();

            if (reCaptchaResult.success == true) {
                JsonValue challenge_ts = outputJSON.get("challenge_ts");
                logger.message("JSON challenge_ts = " + challenge_ts);
                JsonValue hostname = outputJSON.get("hostname");
                logger.message("JSON hostname = " + hostname);

                if (success == null || challenge_ts == null || hostname == null) {
                    throw new Exception("JSON result is missing values.");
                }

                reCaptchaResult.challenge_ts = challenge_ts.asString();
                reCaptchaResult.hostname = hostname.asString();

                if (reCAPTCHAType == FoxtelreCAPTCHATypes.V3) {
                    JsonValue score = outputJSON.get("score");
                    logger.message("JSON score = " + score);
                    JsonValue action = outputJSON.get("action");
                    logger.message("JSON action = " + action);
                    reCaptchaResult.score = score.asDouble();
                    reCaptchaResult.action = action.asString();
                    if (score == null || action == null) {
                        throw new Exception("JSON result is missing values.");
                    }
                }
            } else {
                JsonValue errorcodes = outputJSON.get("error-codes");
                if (errorcodes != null) {
                    logger.message("JSON error-codes = " + errorcodes);
                    reCaptchaResult.errorcodes = errorcodes.asList();
                }
            }
        } catch (Exception e) {
            throw new Exception("Failed to parse JSON = " + e.getMessage());
        }

    }

    private String validateReCaptcha(FoxtelreCAPTCHATypes reCAPTCHAType, double reCAPTCHAv3Threshold) {

        if (!reCaptchaResult.success) {
            return FAILED;
        } else {
            if (!reCaptchaResult.hostname.contains("foxtel.com.au")) {
                logger.error("Hostname doesn't match foxtel.com.au");
                return ERROR;
            }
            if (reCAPTCHAType == FoxtelreCAPTCHATypes.V2 && reCaptchaResult.success) {
                return OK;
            } else if (reCAPTCHAType == FoxtelreCAPTCHATypes.V3 && reCaptchaResult.success) {
                if (reCAPTCHAType == FoxtelreCAPTCHATypes.V3 && !reCaptchaResult.action.equals("OAuthExtLogin")) {
                    logger.error("Action is not OAuthExtLogin");
                    return ERROR;
                }
                if (reCaptchaResult.score >= reCAPTCHAv3Threshold) {
                    return OK;
                } else if (reCaptchaResult.score < reCAPTCHAv3Threshold) {
                    logger.warning("Score of " + reCaptchaResult.score + " below threshold of " + reCAPTCHAv3Threshold);
                    return SUSPECT;
                }
            }
        }

        return ERROR;

    }

    static final class OutcomeProvider implements org.forgerock.openam.auth.node.api.OutcomeProvider {

        @Override
        public List<Outcome> getOutcomes(PreferredLocales locales, JsonValue nodeAttributes) {

            List<Outcome> list = new ArrayList<>();

            list.add(new Outcome(OK, "OK"));
            list.add(new Outcome(SUSPECT, "Suspect"));
            list.add(new Outcome(FAILED, "Failed"));
            list.add(new Outcome(ERROR, "Error"));

            return list;
        }
    }

}
