/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.com.foxtel.reCAPTCHANode;

import com.sun.identity.shared.debug.Debug;

/**
 *
 * @author redfernm
 */
public class FoxtelLogger {

    private Debug debug;
    private String reCAPTCHAType = null;
    private String username = null;
    private String clientIP = null;

    public FoxtelLogger(Debug debug) {
        this.debug = debug;
    }

    public void setReCAPTCHAType(String reCAPTCHAType) {
        this.reCAPTCHAType = reCAPTCHAType;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }
    
    public void error(String message) {
        debug.error(this.log(message));
    }

    public void warning(String message) {
        debug.warning(this.log(message));
    }

    public void message(String message) {
        debug.message(this.log(message));
    }

    private String log(String message) {
        String logMessage = "reCAPTCHA " + reCAPTCHAType + " [" + username + " / " + clientIP + "]: " + message;
        return logMessage;
    }
}
