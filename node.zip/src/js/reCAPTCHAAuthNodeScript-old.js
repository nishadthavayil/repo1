/*
  This script calls the Google reCAPTCHA API to validate the code.
  You must set a few state attributes to get this to run.
  reCAPTCHAType = v3 or v2
  reCAPTCHASecret = xxxxxxxxxxxxxxxxxxxx
  reCAPTCHAv3Score = 0.7
  If the type is v3 and the result is less than reCAPTCHAv3Score then then the result will be "Suspect".
  A suspect result should then have a 2FA or reCAPTCHA v2 challange.
  This node has the following outcomes:
    OK (good score)
    Suspect (bad score)
    Fail (validation problem)
    Error (Could not get result)
 */

function logMsg(message) {
    var logMessage = "reCAPTCHA " + reCAPTCHAType + " [" + username + " / " + clientIP + "]: " + message;
    return logMessage;
}

// This gets the IP from either headers. If not present it will fail.
// This currently means you have to login via a load banacer and not direct to the AM host.
function getClientIP() {
    var clientIP = null;
    var trueClientIP = requestHeaders.get("true-client-ip");
    var xForwardFor = requestHeaders.get("X-Forwarded-For");

    if (trueClientIP !== null) {
        clientIP = trueClientIP.get(0);
    } else if (xForwardFor !== null) {
        var xForwardForSplit = xForwardFor.get(0).split(',');
        clientIP = xForwardForSplit[0];
    }

    // Override internal Foxtel IP to external IP for testing
    if (clientIP !== null && clientIP.indexOf("10.8.") !== -1) {
        clientIP = "203.18.236.135"
    }

    logger.message(logMsg("clientIP = " + clientIP));
    return clientIP;
}

// Make a call to the Google recaptcha endpoint
function getCaptchaResult(reCAPTCHAResponse) {

    var request = new org.forgerock.http.protocol.Request();

    request.setUri("https://www.google.com/recaptcha/api/siteverify");
    request.setMethod("POST");
    request.getHeaders().add("Content-Type", "application/x-www-form-urlencoded");

    var payload = "secret=" + encodeURIComponent(reCAPTCHASecret);
    payload += "&response=" + encodeURIComponent(reCAPTCHAResponse)
    payload += "&remoteip=" + encodeURIComponent(clientIP);

    logger.message(logMsg("payload = " + payload));
    request.getEntity().setString(payload);

    logger.message(logMsg("getEntity = " + request.getEntity()));

    var postHeaders = request.getHeaders();
    logger.message(logMsg("postHeaders.asMapOfHeaders() = " + postHeaders.asMapOfHeaders()));

    var response = httpClient.send(request).get();

    logger.message(logMsg("response.getStatus() = " + response.getStatus().toString()));

    logger.message(logMsg("response.getEntity() = " + response.getEntity()));

    return response
}

// Make sure the Google reCAPTCHA result is good.
function validateCaptcha(result) {

    var validationResult = "Error";

    var result = JSON.parse(response.getEntity());

    /* v3 example result (v2 is missing score and action)
    {
        "success": true,
        "challenge_ts": "2020-05-27T03:01:06Z",
        "hostname": "www.foxtel.com.au",
        "score": 0.9,
        "action": "OAuthExtLogin"
    }*/

    // Validate the payload is correct
    if (
        typeof result.success === 'undefined' ||
        typeof result.challenge_ts === 'undefined' ||
        typeof result.hostname === 'undefined' ||
        (
            reCAPTCHAType === "v3" && (
                result.score === 'undefined' ||
                result.action === 'undefined'
            )
        )
    ) {
        logger.warning(logMsg("reCAPTCHA result payload is invalid"));
        validationResult = "Error";
    }

    // Always log the result out (only way is to do error level)
    var resultMsg = "success - " + result.success + ", ";
    resultMsg += "challenge_ts - " + result.challenge_ts + ", ";
    resultMsg += "hostname - " + result.hostname + ", ";
    if (reCAPTCHAType === "v3") {
        resultMsg += "score - " + result.score + ", ";
        resultMsg += "action - " + result.action + ", ";
    }

    if (result.success !== true) {
        logger.error(logMsg(resultMsg + "outcome - Fail, issue - Not successful."));
        return "Fail";
    }
    if (result.hostname.indexOf(".foxtel.com.au") === -1) {
        logger.error(logMsg(resultMsg + "outcome - Fail, issue - Not from .foxtel.com.au."));
        return "Fail";
    }
    if (reCAPTCHAType === "v3") {
        if (result.action !== "OAuthExtLogin") {
            logger.error(logMsg(resultMsg + "outcome - Fail, issue - Not OAuthExtLogin."));
            return "Fail";
        }
        if (result.score < reCAPTCHAv3Score) {
            logger.error(logMsg(resultMsg + "outcome - Suspect, issue - Score " + result.score + " under threshold " + reCAPTCHAv3Score + "."));
            return "Suspect";
        } else if (result.success === true && result.score >= reCAPTCHAv3Score) {
            logger.error(logMsg(resultMsg + "outcome - OK."));
            return "OK"
        }
    } else if (result.success === true) {
        logger.error(logMsg(resultMsg + "outcome - OK."));
        return "OK"
    }
    logger.error(logMsg(resultMsg + "outcome - Error, issue - Unknown."));
    return "Error"
}

// Get client details
var clientIP = getClientIP();
var username = sharedState.get("username");

// Show the entire shared state for debugging only
logger.message(logMsg("sharedState = " + sharedState.toString()));

// Get all the required parameters
var reCAPTCHASecret = sharedState.get("reCAPTCHASecret");
var reCAPTCHAv3Score = sharedState.get("reCAPTCHAv3Score");

// Get the reCAPTCHA response from the login callback
var reCAPTCHAResponse = null;
var reCAPTCHAType = sharedState.get("reCAPTCHAType");
if (reCAPTCHAType === "v3") {
    reCAPTCHAResponse = sharedState.get("reCAPTCHAv3Code");
    sharedState.remove("reCAPTCHAv3Code");
} else if (reCAPTCHAType === "v2") {
    reCAPTCHAResponse = sharedState.get("reCAPTCHAv2Code");
    sharedState.remove("reCAPTCHAv2Code");
}
logger.message(logMsg("reCAPTCHAResponse from client = " + reCAPTCHAResponse));

// Handle errors
if (reCAPTCHAType === null) {
    logger.error(logMsg("reCAPTCHAType shared state variable is missing."));
    outcome = "Error"
} else if (reCAPTCHASecret === null) {
    logger.error(logMsg("reCAPTCHASecret shared state variable is missing."));
    outcome = "Error"
} else if (reCAPTCHAType === "v3" && reCAPTCHAv3Score === null) {
    logger.error(logMsg("reCAPTCHAv3Score shared state variable is missing."));
    outcome = "Error"
} else if (reCAPTCHAResponse === null) {
    logger.error(logMsg("reCAPTCHA response code is not supplied by the client."));
    outcome = "Error"
} else if (clientIP === null) {
    logger.error(logMsg("Unable to extract the clientIP."));
    outcome = "Error"
} else {
    // Call Google to get the result
    var response = getCaptchaResult(reCAPTCHAResponse);

    // If 200 OK
    var reqStatus = response.getStatus().toString();
    if (reqStatus === "[Status: 200 OK]") {
        // Validate the result
        outcome = validateCaptcha(response);
    } else {
        logger.error(logMsg("reCAPTCHA failed with http code " + reqStatus));
        outcome = "Error"
    }
}

