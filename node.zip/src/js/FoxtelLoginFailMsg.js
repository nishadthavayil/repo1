(function () {
    let foxtelFindErrorMsgDiv = document.getElementById('login-error-msg');
    if (typeof foxtelFindErrorMsgDiv !== 'undefined' && foxtelFindErrorMsgDiv !== null ) {
        foxtelFindErrorMsgDiv.remove();
    }

    let foxtelErrorMsgDiv = document.createElement('div');
    foxtelErrorMsgDiv.classList.add('custom-alert');
    foxtelErrorMsgDiv.classList.add('alert-message-icon');
    foxtelErrorMsgDiv.id = 'login-error-msg';
    foxtelErrorMsgDiv.style.color = '#f2410a';
    
    let foxtelErrorIcon = document.createElement('i');
    foxtelErrorIcon.id = 'login-error-icon';
    foxtelErrorIcon.classList.add('fa');
    foxtelErrorIcon.classList.add('alert-message-icon');
    let foxtelErrorMsg = document.createElement('span');
    foxtelErrorMsg.id = 'login-error-text';
    
    let errorMsg = [];
    errorMsg[0] = "   The username and password you entered did not match our records. Try again, "
    errorMsg[1] = document.createElement('a');
    errorMsg[1].style.color = '#f2410a';
    errorMsg[1].style.textDecoration = 'underline';
    errorMsg[1].innerHTML = "reset your password";
    errorMsg[1].href = "https://www.foxtel.com.au/login/forgot/forgot-password-email-check.html";
    errorMsg[2] = ' or '
    errorMsg[3] = document.createElement('a');
    errorMsg[3].style.color = '#f2410a';
    errorMsg[3].style.textDecoration = 'underline';
    errorMsg[3].innerHTML = "retrieve your username";
    errorMsg[3].href = "https://www.foxtel.com.au/login/forgot/forgot-username.html";
    errorMsg[4] = ".";
    
    foxtelErrorMsg.append(errorMsg[0]);
    foxtelErrorMsg.append(errorMsg[1]);
    foxtelErrorMsg.append(errorMsg[2]);
    foxtelErrorMsg.append(errorMsg[3]);
    foxtelErrorMsg.append(errorMsg[4]);
    foxtelErrorMsgDiv.append(foxtelErrorIcon);
    foxtelErrorMsgDiv.append(foxtelErrorMsg);
    
    let foxtelLoginForm = document.getElementsByTagName("fieldset");
    foxtelLoginForm[0].prepend(foxtelErrorMsgDiv);
})();