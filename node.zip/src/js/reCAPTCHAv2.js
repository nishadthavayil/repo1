const ReCAPTCHAv2Node = function (document, siteKeyIn) {

    const siteKey = siteKeyIn;
    let reCaptchaRdy = false;
    let frComponents = {
        panel: null,
        loginBtn: null,
        inputs: null,
        reCapCode: null
    }
    let widgetId = null;

    //console.log('ReCAPTCHAv2Node loaded started with siteKey ' + siteKey);

    this.init = function () {
        //console.log('Init recaptcha');
        frComponents.panel = document.getElementById('frLoginContainer'); // Grab the panel (this is a custom id)
        //console.log(frComponents);
        frComponents.panel.style.display = 'none'; // hide the entire panel while loading        
        // We don't want the rememberMe box on the v2 screen
        let rememberMe = document.getElementsByClassName("remember-forgot clearfix");
        rememberMe[0].remove();
        injetReCAPTCHA();
    }

    // Injects the reCAPTCHA script into the html DOM.
    const injetReCAPTCHA = function () {
        if (typeof grecaptcha === 'undefined') {
            //console.log('Injecting the reCAPTCHA');
            let recaptchaScript = document.createElement('script');
            recaptchaScript.type = 'text/javascript';
            recaptchaScript.setAttribute('async', '');
            recaptchaScript.setAttribute('defer', '');
            let greCaptcha = 'https://www.google.com/recaptcha/api.js';
            let onloadQry = 'onload=reCaptchaOnLoad';
            let renderQry = 'render=explicit';
            let reCAPTCHAurl = greCaptcha + '?' + onloadQry + '&' + renderQry;
            //console.log('reCAPTCHA URL: ' + reCAPTCHAurl);
            recaptchaScript.src = reCAPTCHAurl;
            document.body.appendChild(recaptchaScript);
        } else {
            //console.log('reCAPTCHA already running');
            reCaptchaOnLoad();
        }
    }

    // reCAPTCHA calls this once it finishes loading which will bootstrap everything else.
    this.reCaptchaOnLoad = function () {
        if (!reCaptchaRdy) {
            //console.log('reCAPTCHA has finished loading.');
            reCaptchaRdy = true;
            waitForDOM();
        } else {
            waitForDOM();
        }
    }

    // Try and find the login button which will be the last thing to render, if not keep trying every 10ms.
    const waitForDOM = function () {
        frComponents.loginBtn = document.querySelector('input[type=submit]');
        if (frComponents.loginBtn === null) {
            setTimeout(function () {
                //console.log('Wait for login button');
                waitForDOM();
            }, 10);
        } else {
            //console.log('Found login button');
            // if the button has been rendeded all inputs should be present.
            frComponents.inputs = document.getElementsByClassName("input-lg");
            // And the hidden field for the recaptcha code to go in to get POSTd back to AM.
            frComponents.reCapCode = document.getElementById('reCAPTCHAv2Code');
            // Hide the submit button as we'll be submitting via the reCAPTCHA click.
            frComponents.loginBtn.style.display = 'none';
            renderReCAPTCHA();
        }
    }

    const renderReCAPTCHA = function () {
        // Add the recaptcha after the hidden div
        //let reCapCode = document.getElementById('reCAPTCHAv3Code');
        let recaptchaDiv = document.createElement('div');
        recaptchaDiv.id = 'reCAPTCHAv2Div';
        recaptchaDiv.class = 'g-recaptcha';
        recaptchaDiv.align = 'center';
        //recaptchaDiv.setAttribute('data-expired-callback', 'aFunction');
        //recaptchaDiv.setAttribute('data-error-callback', 'anotherFunction');
        frComponents.reCapCode.parentNode.append(recaptchaDiv);
        widgetId = grecaptcha.render('reCAPTCHAv2Div', {
            "sitekey": siteKey,
            "callback": reCAPTCHASubmit
        });
        //console.log(widgetId);
        frComponents.panel.style.display = 'block'; // show the panel now we have rendered the reCAPTCHA
    }

    const reCAPTCHASubmit = function () {
        //console.log('reCAPTCHA has been clicked!');
        // Grab the code
        let reCAPTCHArsp = grecaptcha.getResponse(widgetId);
        //console.log(reCAPTCHArsp);
        // Add it to the hidden callback to send to AM
        frComponents.reCapCode.value = reCAPTCHArsp;
        // And now submit the form
        frComponents.loginBtn.click();
    }

}

const reCAPTCHAv2Node = new ReCAPTCHAv2Node(
    document,
    '6LfGgvcUAAAAAOWxQizIPdB1K_g3zxWLG3tbMp70'
);

// reCAPTCHA will call this on load. Has to be in the global scope for it to have access it.
function reCaptchaOnLoad() {
    reCAPTCHAv2Node.reCaptchaOnLoad();
}

reCAPTCHAv2Node.init();